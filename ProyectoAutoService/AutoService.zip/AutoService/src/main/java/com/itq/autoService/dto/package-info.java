//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.3.2 
// Visite <a href="https://javaee.github.io/jaxb-v2/">https://javaee.github.io/jaxb-v2/</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2023.09.28 a las 11:44:03 AM CST 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://com.taller", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.itq.autoService.dto;
